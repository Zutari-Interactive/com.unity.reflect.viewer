// using System;
// using System.Collections.Generic;
// using Unity.Reflect;
// using Unity.Reflect.Model;
// using UnityEngine;
// using UnityEngine.Reflect;
// using UnityEngine.Reflect.Pipeline;
//
// namespace Zutari
// {
//     [Serializable]
//     public class UniversalNode : ReflectNode<NodeProcessorFilter>
//     {
//         public StreamInstanceInput InstanceInput   = new StreamInstanceInput();
//         public GameObjectInput     GameObjectInput = new GameObjectInput();
//
//         protected override NodeProcessorFilter Create(ReflectBootstrapper hook, ISyncModelProvider provider,
//                                                       IExposedPropertyTable resolver)
//         {
//             Debug.Log("Created new NodeProcessorFilter.");
//             NodeProcessorFilter nodeProcessorFilter = new NodeProcessorFilter();
//
//             InstanceInput.streamEvent = nodeProcessorFilter.OnStreamInstanceEvent;
//             GameObjectInput.streamEvent = nodeProcessorFilter.OnGameObjectEvent;
//
//             return nodeProcessorFilter;
//         }
//
//         #region VARIABLES
//
//         // THIS IS FOR YOUR VARIABLES
//
//         #endregion
//
//         #region CUSTOM METHODS
//
//         // THIS IS WHERE YOU ADD YOUR CUSTOM FILTER METHODS
//
//         #endregion
//     }
//
//
//     #region IREFLECT NODE PROCESSOR FILTER
//
//     public class NodeProcessorFilter : IReflectNodeProcessor
//     {
//         class FilterData
//         {
//             public bool                visible   = true;
//             public HashSet<GameObject> instances = new HashSet<GameObject>();
//         }
//
//         private Dictionary<string, FilterData> _instances = new Dictionary<string, FilterData>();
//         private ReflectClient                  _client;
//
//
//         public IEnumerable<string> Categories
//         {
//             get { return _instances.Keys; }
//         }
//
//         public void OnStreamEvent(SyncedData<GameObject> gameObject, StreamEvent streamEvent)
//         {
//             Debug.Log($"STREAM EVEN FIRED - {gameObject.data.name}");
//         }
//
//         public void OnStreamInstanceEvent(SyncedData<StreamInstance> stream, StreamEvent streamEvent)
//         {
//             if (streamEvent != StreamEvent.Added)
//                 return;
//
//             SyncMetadata metadata = stream.data.instance.Metadata;
//
//             if (metadata != null && metadata.Parameters.TryGetValue("$CATEGORY", out SyncParameter category))
//             {
//                 if (!_instances.ContainsKey(category.Value))
//                 {
//                     _instances[category.Value] = new FilterData();
//                 }
//             }
//         }
//
//         public void OnGameObjectEvent(SyncedData<GameObject> gameObjectData, StreamEvent streamEvent)
//         {
//             if (streamEvent == StreamEvent.Added)
//             {
//                 OnGameObjectAdded(gameObjectData.data);
//             }
//             else if (streamEvent == StreamEvent.Removed)
//             {
//                 OnGameObjectRemoved(gameObjectData.data);
//             }
//         }
//
//         void OnGameObjectAdded(GameObject gameObject)
//         {
//             if (!gameObject.TryGetComponent(out Metadata metadata))
//                 return;
//
//             if (metadata.parameters.dictionary.TryGetValue("$CATEGORY", out Metadata.Parameter category))
//             {
//                 if (!_instances.TryGetValue(category.value, out FilterData filter))
//                     return;
//
//                 filter.instances.Add(gameObject);
//
//                 // YOUR CUSTOM CODE GOES HERE, THIS IS A UNIVERSAL CASE
//                 // THIS WILL BE APPLIED TO ALL OBJECTS IMPORTED THROUGH THE PIPELINE
//
//                 // YOUR CODE - START
//
//                 // YOUR CODE - END
//
//                 if (!filter.visible)
//                 {
//                     gameObject.SetActive(false);
//                 }
//             }
//         }
//
//         void OnGameObjectRemoved(GameObject gameObject)
//         {
//             if (!gameObject.TryGetComponent(out Metadata metadata))
//                 return;
//
//             if (metadata.parameters.dictionary.TryGetValue("$CATEGORY", out Metadata.Parameter category))
//             {
//                 if (_instances.TryGetValue(category.value, out FilterData filter))
//                 {
//                     filter.instances.Remove(gameObject);
//                 }
//             }
//         }
//
//         public bool IsVisible(string category)
//         {
//             if (!_instances.TryGetValue(category, out FilterData filter))
//                 return true;
//
//             return filter.visible;
//         }
//
//         public void SetVisibility(string category, bool visible)
//         {
//             if (!_instances.TryGetValue(category, out FilterData filter))
//                 return;
//
//             if (filter.visible == visible)
//                 return;
//
//             filter.visible = visible;
//
//             foreach (GameObject instance in filter.instances)
//             {
//                 instance.SetActive(visible);
//             }
//         }
//
//         public void OnPipelineInitialized()
//         {
//             // OnPipelineInitialized is called the first time the pipeline is run.
//         }
//
//         public void OnPipelineShutdown()
//         {
//             // OnPipelineShutdown is called before the pipeline graph is destroyed.
//         }
//
//         #region VARIABLES
//
//         // THIS IS FOR YOUR VARIABLES
//
//         #endregion
//
//         #region CUSTOM METHODS
//
//         // THIS IS WHERE YOU ADD YOUR CUSTOM FILTER METHODS
//
//         #endregion
//     }
//
//     #endregion
// }
